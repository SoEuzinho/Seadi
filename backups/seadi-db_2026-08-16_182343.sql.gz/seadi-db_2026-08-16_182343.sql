/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.12-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: seadi
-- ------------------------------------------------------
-- Server version	11.4.12-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `Atividade`
--

DROP TABLE IF EXISTS `Atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Atividade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) NOT NULL,
  `tipo` varchar(191) NOT NULL,
  `descricao` varchar(191) NOT NULL,
  `criadoEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Atividade_usuarioId_criadoEm_idx` (`usuarioId`,`criadoEm`),
  CONSTRAINT `Atividade_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Atividade`
--

LOCK TABLES `Atividade` WRITE;
/*!40000 ALTER TABLE `Atividade` DISABLE KEYS */;
INSERT INTO `Atividade` VALUES
(1,1,'pagina_visitada','Visitou a área: cadastro','2026-08-14 22:28:06.409'),
(2,1,'pagina_visitada','Visitou a área: progresson1','2026-08-14 22:28:09.880'),
(3,1,'pagina_visitada','Visitou a área: criadores','2026-08-14 22:28:13.438'),
(4,1,'pagina_visitada','Visitou a área: senha','2026-08-14 22:28:33.120'),
(5,1,'pagina_visitada','Visitou a área: quiz','2026-08-14 22:28:46.862'),
(6,1,'pagina_visitada','Visitou a área: ranking','2026-08-14 22:28:47.398'),
(7,1,'pagina_visitada','Visitou a área: conquistas','2026-08-14 22:28:47.841'),
(8,1,'pagina_visitada','Visitou a área: interativo','2026-08-14 22:28:48.553'),
(9,1,'aula_concluida','Concluiu a aula \"Como Ligar e Desligar\"','2026-08-14 22:29:16.228'),
(10,1,'login','Fez login na plataforma','2026-08-14 22:30:51.885'),
(11,1,'aula_concluida','Concluiu a aula \"Como usar um Mouse\"','2026-08-14 22:31:19.407'),
(12,1,'pagina_visitada','Visitou a área: cadastro','2026-08-14 22:31:28.539'),
(13,1,'pagina_visitada','Visitou a área: quiz','2026-08-14 22:31:34.608'),
(14,1,'pagina_visitada','Visitou a área: ranking','2026-08-14 22:31:41.244'),
(15,2,'pagina_visitada','Visitou a área: cadastro','2026-08-15 21:19:36.947'),
(16,2,'pagina_visitada','Visitou a área: progresson1','2026-08-15 21:19:48.737'),
(17,2,'pagina_visitada','Visitou a área: quiz','2026-08-15 21:19:52.045'),
(18,2,'pagina_visitada','Visitou a área: ranking','2026-08-15 21:19:55.873'),
(19,2,'pagina_visitada','Visitou a área: conquistas','2026-08-15 21:20:10.142'),
(20,2,'pagina_visitada','Visitou a área: interativo','2026-08-15 21:20:30.905'),
(21,2,'pagina_visitada','Visitou a área: criadores','2026-08-15 21:20:34.926'),
(22,2,'perfil_alterado','Alterou os dados cadastrais','2026-08-15 21:22:18.397'),
(23,2,'perfil_alterado','Alterou os dados cadastrais','2026-08-15 21:22:29.454'),
(24,2,'perfil_alterado','Alterou os dados cadastrais','2026-08-15 21:23:02.551'),
(25,2,'perfil_alterado','Alterou os dados cadastrais','2026-08-15 21:23:03.942'),
(26,2,'pagina_visitada','Visitou a área: ranking','2026-08-15 21:34:22.196'),
(27,3,'pagina_visitada','Visitou a área: cadastro','2026-08-16 14:59:03.848'),
(28,3,'pagina_visitada','Visitou a área: quiz','2026-08-16 14:59:05.281'),
(29,3,'pagina_visitada','Visitou a área: ranking','2026-08-16 14:59:07.297'),
(30,3,'pagina_visitada','Visitou a área: conquistas','2026-08-16 14:59:17.559'),
(31,3,'pagina_visitada','Visitou a área: interativo','2026-08-16 14:59:19.315'),
(32,3,'pagina_visitada','Visitou a área: criadores','2026-08-16 14:59:28.988'),
(33,3,'pagina_visitada','Visitou a área: progresson1','2026-08-16 15:00:23.063'),
(34,3,'aula_concluida','Concluiu a aula \"Como Ligar e Desligar\"','2026-08-16 15:01:21.175'),
(35,3,'aula_concluida','Concluiu a aula \"Como usar um Mouse\"','2026-08-16 15:01:55.627'),
(36,3,'aula_concluida','Concluiu a aula \"Como usar o Teclado\"','2026-08-16 15:02:11.346'),
(37,3,'simulador_concluido','simulador:mouse','2026-08-16 15:03:11.686'),
(38,3,'simulador_concluido','simulador:navegador','2026-08-16 15:03:27.854'),
(39,3,'simulador_concluido','simulador:pendrive','2026-08-16 15:03:37.999'),
(40,3,'simulador_concluido','simulador:redes','2026-08-16 15:03:43.622'),
(41,3,'simulador_concluido','simulador:janelas','2026-08-16 15:03:50.829'),
(42,3,'simulador_concluido','simulador:teclado','2026-08-16 15:04:03.091'),
(43,3,'simulador_concluido','simulador:ligar','2026-08-16 15:04:15.652'),
(44,3,'aula_concluida','Concluiu a aula \"Conhecendo o Windows\"','2026-08-16 15:05:26.340'),
(45,3,'aula_concluida','Concluiu a aula \"Área de trabalho\"','2026-08-16 15:05:32.915'),
(46,3,'aula_concluida','Concluiu a aula \"Abrindo programas\"','2026-08-16 15:05:37.390'),
(47,3,'aula_concluida','Concluiu a aula \"Internet básica\"','2026-08-16 15:05:40.964'),
(48,3,'aula_concluida','Concluiu a aula \"Wi-Fi e conexão\"','2026-08-16 15:05:44.606'),
(49,3,'aula_concluida','Concluiu a aula \"Usando Janelas\"','2026-08-16 15:05:49.172'),
(50,3,'modulo_concluido','Completou o módulo \"Iniciante\"','2026-08-16 15:05:49.199'),
(51,3,'pagina_visitada','Visitou a área: senha','2026-08-16 15:06:21.573'),
(52,3,'pagina_visitada','Visitou a área: quiz','2026-08-16 15:10:21.723'),
(53,1,'login','Fez login na plataforma','2026-08-16 15:17:11.778'),
(54,1,'pagina_visitada','Visitou a área: cadastro','2026-08-16 15:17:14.962'),
(55,1,'pagina_visitada','Visitou a área: quiz','2026-08-16 15:17:17.413'),
(56,3,'pagina_visitada','Visitou a área: quiz','2026-08-16 15:28:47.130'),
(57,3,'pagina_visitada','Visitou a área: ranking','2026-08-16 15:28:49.971'),
(58,3,'pagina_visitada','Visitou a área: conquistas','2026-08-16 15:31:16.430'),
(59,3,'pagina_visitada','Visitou a área: interativo','2026-08-16 15:31:17.315'),
(60,3,'pagina_visitada','Visitou a área: interativo','2026-08-16 16:20:32.329'),
(61,3,'pagina_visitada','Visitou a área: cadastro','2026-08-16 16:21:11.826'),
(62,3,'pagina_visitada','Visitou a área: quiz','2026-08-16 16:21:12.933'),
(63,3,'pagina_visitada','Visitou a área: ranking','2026-08-16 16:21:13.547'),
(64,3,'pagina_visitada','Visitou a área: conquistas','2026-08-16 16:21:30.524'),
(65,3,'pagina_visitada','Visitou a área: criadores','2026-08-16 16:21:38.426'),
(66,3,'pagina_visitada','Visitou a área: criadores','2026-08-16 17:56:17.800'),
(67,3,'pagina_visitada','Visitou a área: ranking','2026-08-16 17:56:22.327'),
(68,3,'pagina_visitada','Visitou a área: conquistas','2026-08-16 17:56:23.099'),
(69,3,'pagina_visitada','Visitou a área: interativo','2026-08-16 17:56:29.418'),
(70,3,'pagina_visitada','Visitou a área: progresson1','2026-08-16 18:02:21.954');
/*!40000 ALTER TABLE `Atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Aula`
--

DROP TABLE IF EXISTS `Aula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moduloId` int(11) NOT NULL,
  `ordem` int(11) NOT NULL,
  `titulo` varchar(191) NOT NULL,
  `descricao` varchar(191) DEFAULT NULL,
  `videoUrl` varchar(191) DEFAULT NULL,
  `conteudo` varchar(191) DEFAULT NULL,
  `duracao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Aula_moduloId_fkey` (`moduloId`),
  CONSTRAINT `Aula_moduloId_fkey` FOREIGN KEY (`moduloId`) REFERENCES `Modulo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Aula`
--

LOCK TABLES `Aula` WRITE;
/*!40000 ALTER TABLE `Aula` DISABLE KEYS */;
INSERT INTO `Aula` VALUES
(1,1,1,'Como Ligar e Desligar',NULL,'https://www.youtube.com/embed/-m7jRtUrh4U',NULL,120),
(2,1,2,'Como usar um Mouse',NULL,NULL,NULL,180),
(3,1,3,'Como usar o Teclado',NULL,NULL,NULL,240),
(4,1,4,'Conhecendo o Windows',NULL,NULL,NULL,300),
(5,1,5,'Área de trabalho',NULL,NULL,NULL,200),
(6,1,6,'Abrindo programas',NULL,NULL,NULL,150),
(7,1,7,'Internet básica',NULL,NULL,NULL,250),
(8,1,8,'Wi-Fi e conexão',NULL,NULL,NULL,180),
(9,1,9,'Usando Janelas',NULL,NULL,NULL,220),
(10,2,1,'Google e Navegação',NULL,NULL,NULL,180),
(11,2,2,'Como Pesquisar',NULL,NULL,NULL,240),
(12,2,3,'Digitando Texto',NULL,NULL,NULL,300),
(13,2,4,'Usando Pontos e Acentuações',NULL,NULL,NULL,200),
(14,2,5,'Criando e Organizando Arquivos',NULL,NULL,NULL,250),
(15,2,6,'Noções Básicas de Arquivos',NULL,NULL,NULL,150),
(16,2,7,'Baixando Arquivos',NULL,NULL,NULL,180),
(17,2,8,'Criando e-mail',NULL,NULL,NULL,300),
(18,2,9,'Comunicação online',NULL,NULL,NULL,200),
(19,2,10,'Aplicativos Úteis',NULL,NULL,NULL,200),
(20,2,11,'Acessibilidade rápida',NULL,NULL,NULL,120),
(21,3,1,'Organização digital',NULL,NULL,NULL,240),
(22,3,2,'Atualizações e cuidados',NULL,NULL,NULL,180),
(23,3,3,'Segurança básica',NULL,NULL,NULL,300),
(24,3,4,'Teclas de atalho (Parte 1)',NULL,NULL,NULL,200),
(25,3,5,'Teclas de atalho (Parte 2)',NULL,NULL,NULL,220),
(26,3,6,'Teclas de atalho (Parte 3)',NULL,NULL,NULL,180),
(27,3,7,'Teclas de atalho (Parte 4)',NULL,NULL,NULL,250),
(28,3,8,'Usando pen drive',NULL,NULL,NULL,200),
(29,3,9,'Problemas simples e soluções rápidas',NULL,NULL,NULL,300);
/*!40000 ALTER TABLE `Aula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Conquista`
--

DROP TABLE IF EXISTS `Conquista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Conquista` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `obtidaEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `Conquista_usuarioId_slug_key` (`usuarioId`,`slug`),
  CONSTRAINT `Conquista_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Conquista`
--

LOCK TABLES `Conquista` WRITE;
/*!40000 ALTER TABLE `Conquista` DISABLE KEYS */;
INSERT INTO `Conquista` VALUES
(1,1,'visitou-diversoes','2026-08-14 22:28:47.862'),
(2,1,'visitou-conta','2026-08-14 22:28:47.862'),
(3,1,'primeira-aula','2026-08-14 22:31:52.710'),
(4,1,'primeiro-login','2026-08-14 22:31:52.710'),
(5,2,'visitou-conta','2026-08-15 21:20:10.164'),
(6,2,'visitou-diversoes','2026-08-15 21:20:10.164'),
(7,3,'visitou-conta','2026-08-16 14:59:17.626'),
(8,3,'visitou-diversoes','2026-08-16 14:59:17.626'),
(9,3,'primeira-aula','2026-08-16 15:02:31.365'),
(10,3,'aulas-em-um-dia','2026-08-16 15:02:31.365'),
(11,3,'simulador-janelas','2026-08-16 15:04:17.263'),
(12,3,'mestre-simuladores','2026-08-16 15:04:17.263'),
(13,3,'simulador-ligar','2026-08-16 15:04:17.263'),
(14,3,'simulador-redes','2026-08-16 15:04:17.264'),
(15,3,'simulador-mouse','2026-08-16 15:04:17.264'),
(16,3,'simulador-teclado','2026-08-16 15:04:17.264'),
(17,3,'simulador-quatro','2026-08-16 15:04:17.264'),
(18,3,'progresso-25','2026-08-16 15:07:17.968'),
(19,3,'cinco-aulas','2026-08-16 15:07:17.968'),
(20,3,'modulo-iniciante','2026-08-16 15:07:17.968'),
(21,3,'primeiro-quiz','2026-08-16 15:31:16.452'),
(22,3,'vitoria-quiz','2026-08-16 15:31:16.452');
/*!40000 ALTER TABLE `Conquista` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Modulo`
--

DROP TABLE IF EXISTS `Modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Modulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ordem` int(11) NOT NULL,
  `titulo` varchar(191) NOT NULL,
  `descricao` varchar(191) DEFAULT NULL,
  `icone` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Modulo_ordem_key` (`ordem`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Modulo`
--

LOCK TABLES `Modulo` WRITE;
/*!40000 ALTER TABLE `Modulo` DISABLE KEYS */;
INSERT INTO `Modulo` VALUES
(1,1,'Iniciante','Primeiros passos no computador','inici.png'),
(2,2,'Básico','Fundamentos para o dia a dia','avanç.png'),
(3,3,'Avançado','Conceitos avançados e produtividade','intermed.png');
/*!40000 ALTER TABLE `Modulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartidaQuiz`
--

DROP TABLE IF EXISTS `PartidaQuiz`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `PartidaQuiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) NOT NULL,
  `categoria` varchar(191) NOT NULL,
  `posicao` int(11) NOT NULL,
  `pontos` int(11) NOT NULL,
  `acertos` int(11) NOT NULL,
  `erros` int(11) NOT NULL,
  `tempoMedioResposta` double NOT NULL,
  `percentualAcertos` double NOT NULL,
  `totalPerguntas` int(11) NOT NULL,
  `concluidaEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `PartidaQuiz_usuarioId_concluidaEm_idx` (`usuarioId`,`concluidaEm`),
  CONSTRAINT `PartidaQuiz_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartidaQuiz`
--

LOCK TABLES `PartidaQuiz` WRITE;
/*!40000 ALTER TABLE `PartidaQuiz` DISABLE KEYS */;
INSERT INTO `PartidaQuiz` VALUES
(1,3,'iniciante',1,643,8,7,4.29,53.3,15,'2026-08-16 15:20:18.612'),
(2,1,'iniciante',2,288,3,12,2.71,20,15,'2026-08-16 15:20:18.612');
/*!40000 ALTER TABLE `PartidaQuiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProgressoAula`
--

DROP TABLE IF EXISTS `ProgressoAula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProgressoAula` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) NOT NULL,
  `aulaId` int(11) NOT NULL,
  `videoAssistido` tinyint(1) NOT NULL DEFAULT 0,
  `progressoVideo` int(11) NOT NULL DEFAULT 0,
  `tempoAssistido` int(11) NOT NULL DEFAULT 0,
  `concluido` tinyint(1) NOT NULL DEFAULT 0,
  `assistidoEm` datetime(3) DEFAULT NULL,
  `concluidoEm` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProgressoAula_usuarioId_aulaId_key` (`usuarioId`,`aulaId`),
  KEY `ProgressoAula_aulaId_fkey` (`aulaId`),
  CONSTRAINT `ProgressoAula_aulaId_fkey` FOREIGN KEY (`aulaId`) REFERENCES `Aula` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ProgressoAula_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProgressoAula`
--

LOCK TABLES `ProgressoAula` WRITE;
/*!40000 ALTER TABLE `ProgressoAula` DISABLE KEYS */;
INSERT INTO `ProgressoAula` VALUES
(1,1,1,1,100,0,1,'2026-08-14 22:29:16.163','2026-08-14 22:29:16.163'),
(2,1,2,1,99,72,1,'2026-08-14 22:31:20.554','2026-08-14 22:31:19.379'),
(3,3,1,1,100,43,1,'2026-08-16 15:01:26.150','2026-08-16 15:01:21.149'),
(4,3,2,1,100,17,1,'2026-08-16 15:01:55.588','2026-08-16 15:01:55.588'),
(5,3,3,1,100,55,1,'2026-08-16 15:02:11.330','2026-08-16 15:02:11.330'),
(6,3,4,1,100,0,1,'2026-08-16 15:05:26.263','2026-08-16 15:05:26.263'),
(7,3,5,1,100,0,1,'2026-08-16 15:05:32.883','2026-08-16 15:05:32.883'),
(8,3,6,1,100,0,1,'2026-08-16 15:05:37.310','2026-08-16 15:05:37.310'),
(9,3,7,1,100,0,1,'2026-08-16 15:05:40.933','2026-08-16 15:05:40.933'),
(10,3,8,1,100,0,1,'2026-08-16 15:05:44.543','2026-08-16 15:05:44.543'),
(11,3,9,1,99,26,1,'2026-08-16 15:05:55.408','2026-08-16 15:05:49.091');
/*!40000 ALTER TABLE `ProgressoAula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProgressoModulo`
--

DROP TABLE IF EXISTS `ProgressoModulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProgressoModulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) NOT NULL,
  `moduloId` int(11) NOT NULL,
  `progresso` double NOT NULL DEFAULT 0,
  `concluido` tinyint(1) NOT NULL DEFAULT 0,
  `iniciadoEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `concluidoEm` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProgressoModulo_usuarioId_moduloId_key` (`usuarioId`,`moduloId`),
  KEY `ProgressoModulo_moduloId_fkey` (`moduloId`),
  CONSTRAINT `ProgressoModulo_moduloId_fkey` FOREIGN KEY (`moduloId`) REFERENCES `Modulo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ProgressoModulo_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProgressoModulo`
--

LOCK TABLES `ProgressoModulo` WRITE;
/*!40000 ALTER TABLE `ProgressoModulo` DISABLE KEYS */;
INSERT INTO `ProgressoModulo` VALUES
(1,1,1,22,0,'2026-08-14 22:29:16.259',NULL),
(2,3,1,100,1,'2026-08-16 15:01:21.190','2026-08-16 15:05:49.185');
/*!40000 ALTER TABLE `ProgressoModulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Questao`
--

DROP TABLE IF EXISTS `Questao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Questao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(191) NOT NULL,
  `enunciado` varchar(191) NOT NULL,
  `alternativaA` varchar(191) NOT NULL,
  `alternativaB` varchar(191) NOT NULL,
  `alternativaC` varchar(191) NOT NULL,
  `correta` int(11) NOT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT 1,
  `criadoEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Questao_categoria_idx` (`categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Questao`
--

LOCK TABLES `Questao` WRITE;
/*!40000 ALTER TABLE `Questao` DISABLE KEYS */;
INSERT INTO `Questao` VALUES
(1,'iniciante','Como você deve desligar o computador corretamente?','Pelo menu Iniciar, escolhendo Desligar','Puxando o fio da tomada','Segurando o botão de energia por 10 segundos',0,1,'2026-08-14 22:12:15.322'),
(2,'iniciante','Qual é o primeiro passo para usar o computador?','Ligar na tomada e apertar o botão de energia','Desconectar o mouse','Apagar os arquivos antigos',0,1,'2026-08-14 22:12:15.322'),
(3,'iniciante','Qual botão do mouse é usado para selecionar (clicar) um item?','Botão esquerdo','Botão direito','Botão do meio',0,1,'2026-08-14 22:12:15.322'),
(4,'iniciante','O que normalmente acontece ao dar um clique duplo em um ícone?','Abre um arquivo ou programa','Apaga o arquivo','Desliga o computador',0,1,'2026-08-14 22:12:15.322'),
(5,'iniciante','Para que serve a tecla Enter no teclado?','Confirmar ou enviar uma ação','Apagar o que foi digitado','Mudar o idioma do teclado',0,1,'2026-08-14 22:12:15.322'),
(6,'iniciante','O que é a Área de Trabalho (Desktop) do Windows?','A primeira tela que aparece após ligar o computador','Um programa de desenho','Uma mesa de escritório conectada ao computador',0,1,'2026-08-14 22:12:15.322'),
(7,'iniciante','O que a barra de tarefas do Windows mostra?','Os programas abertos e o botão Iniciar','A senha do usuário','A data de fabricação do computador',0,1,'2026-08-14 22:12:15.322'),
(8,'iniciante','Qual é a maneira mais comum de abrir um programa?','Clicar duas vezes no ícone do programa','Desligar e religar o computador','Puxar o cabo de rede',0,1,'2026-08-14 22:12:15.322'),
(9,'iniciante','Para que serve o botão \"minimizar\" de uma janela?','Esconder a janela sem fechar o programa','Fechar o programa de vez','Apagar o arquivo aberto',0,1,'2026-08-14 22:12:15.322'),
(10,'iniciante','O que é a internet?','Uma rede mundial que conecta computadores','Um programa instalado no computador','Um tipo de monitor',0,1,'2026-08-14 22:12:15.322'),
(11,'iniciante','O que é Wi-Fi?','Um tipo de cabo de rede','Uma rede sem fio','Um programa de navegação',1,1,'2026-08-14 22:12:15.322'),
(12,'iniciante','Qual dispositivo conecta sua casa à internet?','Monitor','Roteador','Teclado',1,1,'2026-08-14 22:12:15.322'),
(13,'iniciante','O que é um navegador (browser)?','Um programa para acessar páginas da internet','Um antivírus','Um servidor de e-mail',0,1,'2026-08-14 22:12:15.322'),
(14,'iniciante','Qual aparelho permite que vários dispositivos usem a internet ao mesmo tempo?','Impressora','Roteador','Caixa de som',1,1,'2026-08-14 22:12:15.322'),
(15,'iniciante','O que significa a sigla IP?','Internet Protocol','Internal Program','Internet Password',0,1,'2026-08-14 22:12:15.322'),
(16,'basico','Qual é um exemplo de navegador de internet?','Google Chrome','Explorador de Arquivos do Windows','Calculadora',0,1,'2026-08-14 22:12:15.322'),
(17,'basico','Para pesquisar na internet, o que você digita no Google?','Palavras-chave sobre o assunto','A senha do Wi-Fi','O número do computador',0,1,'2026-08-14 22:12:15.322'),
(18,'basico','Qual tecla você usa para digitar uma letra maiúscula?','Shift','Esc','Backspace',0,1,'2026-08-14 22:12:15.322'),
(19,'basico','Como se chama o arquivo que você baixa (transfere) da internet para o computador?','Download','Upload','Login',0,1,'2026-08-14 22:12:15.322'),
(20,'basico','Qual programa serve para escrever e editar textos?','Bloco de Notas ou WordPad','Calculadora','Jogo de Paciência',0,1,'2026-08-14 22:12:15.322'),
(21,'basico','Qual símbolo é obrigatório em um endereço de e-mail?','@','#','&',0,1,'2026-08-14 22:12:15.322'),
(22,'basico','Para criar um e-mail, normalmente você precisa de um endereço e...','Uma senha','Uma impressora','Um pen drive',0,1,'2026-08-14 22:12:15.322'),
(23,'basico','O que significa \"responder\" a um e-mail?','Escrever uma mensagem de volta para quem enviou','Apagar o e-mail','Desligar o computador',0,1,'2026-08-14 22:12:15.322'),
(24,'basico','Qual aplicativo permite conversar por mensagens pela internet?','WhatsApp Web','Bloco de Notas','Gerenciador de Arquivos',0,1,'2026-08-14 22:12:15.322'),
(25,'basico','Para que serve a Lixeira do Windows?','Guardar arquivos apagados temporariamente','Acelerar a internet','Instalar programas',0,1,'2026-08-14 22:12:15.322'),
(26,'basico','O que é um endereço de e-mail?','Uma identificação para enviar e receber mensagens','O endereço físico da casa','Um número de telefone',0,1,'2026-08-14 22:12:15.322'),
(27,'basico','O que significa a sigla URL?','Uniform Resource Locator','Universal Remote Link','User Response Label',0,1,'2026-08-14 22:12:15.322'),
(28,'basico','O que significa \"encaminhar\" um e-mail?','Enviar o e-mail para outra pessoa','Deletar o e-mail','Imprimir o e-mail',0,1,'2026-08-14 22:12:15.322'),
(29,'basico','Qual tecla é usada para apagar o que está atrás do cursor?','Backspace','Enter','Caps Lock',0,1,'2026-08-14 22:12:15.322'),
(30,'avancado','Para que servem as atualizações do sistema?','Corrigir erros e melhorar a segurança','Apagar arquivos do usuário','Trocar a cor do monitor',0,1,'2026-08-14 22:12:15.322'),
(31,'avancado','O que é uma senha forte?','Uma senha longa com letras, números e símbolos','Sua data de nascimento','A mesma senha usada em todos os sites',0,1,'2026-08-14 22:12:15.322'),
(32,'avancado','Qual tecla de atalho copia um item no Windows?','Ctrl + C','Ctrl + V','Ctrl + Z',0,1,'2026-08-14 22:12:15.322'),
(33,'avancado','Qual tecla de atalho cola um item no Windows?','Ctrl + V','Ctrl + C','Alt + F4',0,1,'2026-08-14 22:12:15.322'),
(34,'avancado','Qual tecla de atalho desfaz a última ação?','Ctrl + Z','Ctrl + P','Ctrl + S',0,1,'2026-08-14 22:12:15.322'),
(35,'avancado','Qual tecla de atalho salva um arquivo?','Ctrl + S','Ctrl + D','Ctrl + L',0,1,'2026-08-14 22:12:15.322'),
(36,'avancado','Para que serve um pen drive?','Armazenar e transportar arquivos','Aumentar o volume do computador','Melhorar o sinal do Wi-Fi',0,1,'2026-08-14 22:12:15.322'),
(37,'avancado','O que você deve fazer antes de retirar um pen drive do computador?','Ejetá-lo com segurança','Desligar a luz da sala','Apagar todos os arquivos dele',0,1,'2026-08-14 22:12:15.322'),
(38,'avancado','O que é fazer backup dos arquivos?','Guardar uma cópia em outro lugar','Apagar os arquivos antigos','Enviar os arquivos por carta',0,1,'2026-08-14 22:12:15.322'),
(39,'avancado','Se o computador estiver lento, uma boa primeira atitude é...','Fechar os programas que não estão em uso','Puxar o cabo de energia','Comprar um monitor novo',0,1,'2026-08-14 22:12:15.322'),
(40,'avancado','O que é um vírus de computador?','Um programa malicioso que pode danificar o sistema','Uma falha de hardware','Um tipo de rede',0,1,'2026-08-14 22:12:15.322'),
(41,'avancado','Qual é o protocolo seguro para navegar na internet?','HTTP','HTTPS','FTP',1,1,'2026-08-14 22:12:15.322'),
(42,'avancado','Para que serve uma senha forte na internet?','Decorar o acesso','Proteger suas contas de invasores','Acelerar a conexão',1,1,'2026-08-14 22:12:15.322'),
(43,'avancado','Qual atitude ajuda a manter o computador organizado?','Criar pastas com nomes claros e guardar arquivos nelas','Salvar tudo na Área de Trabalho','Nunca apagar arquivos',0,1,'2026-08-14 22:12:15.322'),
(44,'iniciante','Onde fica, geralmente, o botão de ligar de um computador de mesa?','Na frente do gabinete','Atrás do monitor','Embaixo do teclado',0,1,'2026-08-14 22:12:15.322'),
(45,'iniciante','Por que você NUNCA deve puxar o fio da tomada para desligar o computador?','Pode danificar o sistema e causar perda de dados','Aumenta o consumo de energia','Deixa o computador mais lento',0,1,'2026-08-14 22:12:15.322'),
(46,'iniciante','Qual é a forma correta de desligar o Windows?','Puxar o fio da tomada','Clicar no menu Iniciar, no botão de energia e escolher Desligar','Segurar o botão de ligar por 10 segundos',1,1,'2026-08-14 22:12:15.322'),
(47,'iniciante','Depois de clicar em \"Desligar\", o que você deve fazer?','Desligar imediatamente na tomada','Fechar o gabinete','Aguardar a tela apagar por completo',2,1,'2026-08-14 22:12:15.322'),
(48,'iniciante','Para que serve o botão direito do mouse?','Seleciona itens','Abre um menu com opções adicionais, como Copiar e Colar','Rola a página',1,1,'2026-08-14 22:12:15.322'),
(49,'iniciante','Para que serve a rodinha (scroll) do mouse?','Rolar a página para cima e para baixo','Abrir programas','Fechar janelas',0,1,'2026-08-14 22:12:15.322'),
(50,'iniciante','No celular, como são chamados os programas?','Aplicativos (apps)','Sistemas','Gadgets',0,1,'2026-08-14 22:12:15.322'),
(51,'iniciante','Qual é a tecla mais longa do teclado?','Barra de espaço','Enter','Shift',0,1,'2026-08-14 22:12:15.322'),
(52,'iniciante','O que a tecla Backspace apaga?','O que foi escrito, da direita para a esquerda','A linha inteira de uma vez','Somente letras maiúsculas',0,1,'2026-08-14 22:12:15.322'),
(53,'iniciante','O que faz a tecla Caps Lock?','Confirma uma ação','Apaga a palavra inteira','Deixa todas as letras maiúsculas',2,1,'2026-08-14 22:12:15.322'),
(54,'iniciante','Como você digita uma letra maiúscula com a tecla Shift?','Segurando Shift e pressionando a letra desejada','Pressionando Shift duas vezes','Pressionando Shift e Enter juntos',0,1,'2026-08-14 22:12:15.322'),
(55,'iniciante','Em uma tecla com dois caracteres (como o 8 e o asterisco), o que acontece se você segurar Shift?','O número é digitado','O símbolo de cima é digitado','Nada acontece',1,1,'2026-08-14 22:12:15.322'),
(56,'iniciante','O que é o Windows?','Um programa de desenho','O sistema operacional do computador, o \"cérebro\" que faz tudo funcionar','Um navegador de internet',1,1,'2026-08-14 22:12:15.322'),
(57,'iniciante','O que aparece na tela quando você liga o computador?','Uma tela de bloqueio','A Lixeira','O menu Iniciar aberto',0,1,'2026-08-14 22:12:15.322'),
(58,'iniciante','O que você precisa fazer na tela de bloqueio para entrar no sistema?','Pressionar Enter','Digitar a senha','Clicar em Desligar',1,1,'2026-08-14 22:12:15.322'),
(59,'iniciante','O que são os desenhos pequenos (ícones) na Área de Trabalho?','Apenas enfeites da tela','Atalhos para abrir programas e arquivos','Imagens baixadas da internet',1,1,'2026-08-14 22:12:15.322'),
(60,'iniciante','Onde fica a barra de tarefas do Windows?','No topo da tela','No canto superior direito','Na parte de baixo da tela',2,1,'2026-08-14 22:12:15.322'),
(61,'iniciante','Onde fica o botão Iniciar?','No canto esquerdo da barra de tarefas','No canto direito da tela','No centro da Área de Trabalho',0,1,'2026-08-14 22:12:15.322'),
(62,'iniciante','Qual programa do Windows serve para desenhar?','Calculadora','Paint','Bloco de Notas',1,1,'2026-08-14 22:12:15.322'),
(63,'iniciante','Como você acessa um site específico diretamente?','Digitando o endereço completo na barra superior do navegador','Clicando no botão Iniciar','Procurando na Lixeira',0,1,'2026-08-14 22:12:15.322'),
(64,'iniciante','Onde fica o ícone de rede (antena/globo) no Windows?','No menu Iniciar','No canto inferior direito da tela','No meio da Área de Trabalho',1,1,'2026-08-14 22:12:15.322'),
(65,'iniciante','Para conectar o computador à sua rede Wi-Fi, você precisa...','Escolher a rede, digitar a senha e confirmar','Apenas clicar no ícone de rede','Digitar o nome no Word',0,1,'2026-08-14 22:12:15.322'),
(66,'iniciante','O que é uma janela no computador?','Um local para ver fotos','A moldura em que cada programa aberto funciona','A tela de bloqueio',1,1,'2026-08-14 22:12:15.322'),
(67,'iniciante','O que faz o botão Maximizar de uma janela?','Esconde a janela na barra de tarefas','Fecha o programa','Expande a janela para ocupar a tela inteira',2,1,'2026-08-14 22:12:15.322'),
(68,'iniciante','O que faz o botão \"X\" no canto de uma janela?','Fecha o programa por completo','Minimiza a janela','Atualiza a página',0,1,'2026-08-14 22:12:15.322'),
(69,'basico','Como você abre uma nova aba no navegador?','Clicando no sinal de + no topo da janela','Clicando no botão Iniciar','Pressionando Delete',0,1,'2026-08-14 22:12:15.322'),
(70,'basico','Como alternar entre as abas abertas do navegador?','Fechando o navegador','Clicando com o botão esquerdo sobre a aba desejada','Pressionando o botão direito do mouse',1,1,'2026-08-14 22:12:15.322'),
(71,'basico','Para atualizar (recarregar) uma página que travou, você deve...','Fechar o navegador','Desligar o computador','Clicar no símbolo de seta arredondada',2,1,'2026-08-14 22:12:15.322'),
(72,'basico','Qual é a melhor forma de pesquisar algo no Google?','Usar frases longas e completas','Usar palavras-chave diretas','Escrever tudo em maiúsculas',1,1,'2026-08-14 22:12:15.322'),
(73,'basico','Quais abas de filtro o Google costuma mostrar nos resultados?','Tudo, Vídeos, Imagens, Notícias e Shopping','Tudo, Músicas, Jogos e Filmes','Apenas a aba Imagens',0,1,'2026-08-14 22:12:15.322'),
(74,'basico','Como você seleciona uma palavra inteira de uma só vez?','Clicando uma vez sobre ela','Pressionando Caps Lock','Dando dois cliques rápidos sobre a palavra',2,1,'2026-08-14 22:12:15.322'),
(75,'basico','Qual é o primeiro passo para copiar um texto?','Selecionar o texto arrastando o mouse sobre as palavras','Apagar o texto','Fechar o documento',0,1,'2026-08-14 22:12:15.322'),
(76,'basico','Depois de copiar um texto, como você cola no local desejado?','Clicando com o botão direito no local e escolhendo Colar','Pressionando Delete','Clicando duas vezes',0,1,'2026-08-14 22:12:15.322'),
(77,'basico','Qual é o segredo da acentuação no teclado?','Pressionar a tecla do acento antes da letra','Pressionar a letra antes do acento','Usar apenas letras maiúsculas',0,1,'2026-08-14 22:12:15.322'),
(78,'basico','Para digitar a letra \"á\", você deve...','Pressionar a tecla do acento agudo (´) e depois a letra A','Pressionar a letra A duas vezes','Segurar Shift e pressionar A',0,1,'2026-08-14 22:12:15.322'),
(79,'basico','Como você digita o símbolo que fica na parte de cima de uma tecla?','Pressionando a tecla duas vezes','Segurando a tecla Shift e pressionando a tecla do símbolo','Pressionando Enter',1,1,'2026-08-14 22:12:15.322'),
(80,'basico','O que é uma pasta no computador?','Um arquivo de texto','Uma imagem','Uma \"gaveta\" para guardar seus arquivos',2,1,'2026-08-14 22:12:15.322'),
(81,'basico','Como você cria uma pasta nova no Explorador de Arquivos?','Clicando com o botão direito em um espaço vazio, indo em Novo e clicando em Pasta','Pressionando Enter','Arrastando um arquivo para a Lixeira',0,1,'2026-08-14 22:12:15.322'),
(82,'basico','Como você renomeia um arquivo?','Clicando duas vezes nele','Clicando com o botão direito sobre ele e escolhendo Renomear','Arrastando-o para a barra de tarefas',1,1,'2026-08-14 22:12:15.322'),
(83,'basico','Como você exclui um arquivo selecionado?','Pressionando a tecla Delete','Pressionando Caps Lock','Clicando com o botão direito e escolhendo Copiar',0,1,'2026-08-14 22:12:15.322'),
(84,'basico','Para mover um arquivo para outra pasta, você deve...','Apagar e recriar o arquivo','Arrastá-lo segurando o botão esquerdo até a pasta de destino e soltar','Clicar nele com o botão direito',1,1,'2026-08-14 22:12:15.322'),
(85,'basico','Onde fica a opção \"Salvar como\" na maioria dos programas?','No menu Arquivo, no canto superior esquerdo','Na barra de tarefas','No botão Iniciar',0,1,'2026-08-14 22:12:15.322'),
(86,'basico','Qual extensão indica um arquivo de vídeo?','.pdf','.mp4','.docx',1,1,'2026-08-14 22:12:15.322'),
(87,'basico','Qual extensão indica um arquivo de imagem ou foto?','.jpg ou .png','.zip','.mp4',0,1,'2026-08-14 22:12:15.322'),
(88,'basico','Qual extensão indica um arquivo de texto do Word?','.rar','.png','.docx',2,1,'2026-08-14 22:12:15.322'),
(89,'basico','Para que servem os arquivos .zip ou .rar?','Para compactar vários arquivos ocupando menos espaço','Para tocar músicas','Para editar fotos',0,1,'2026-08-14 22:12:15.322'),
(90,'basico','O que é um arquivo .pdf?','Um arquivo de vídeo','Um formato de leitura fechado, como um livro digital, boleto ou contrato','Uma pasta compactada',1,1,'2026-08-14 22:12:15.322'),
(91,'basico','O que significa \"baixar\" (fazer Download) um arquivo?','Enviar um arquivo para a internet','Trazer um arquivo ou foto da internet para dentro do computador','Apagar um arquivo do computador',1,1,'2026-08-14 22:12:15.322'),
(92,'basico','Onde os arquivos baixados da internet são salvos por padrão?','Na pasta Downloads','Na Lixeira','No Paint',0,1,'2026-08-14 22:12:15.322'),
(93,'basico','De onde você deve baixar arquivos com segurança?','De qualquer site','De sites conhecidos e confiáveis','De e-mails de desconhecidos',1,1,'2026-08-14 22:12:15.322'),
(94,'basico','O que é um e-mail?','Um jogo online','Uma rede social','Seu endereço de correspondência na internet',2,1,'2026-08-14 22:12:15.322'),
(95,'basico','Para enviar uma mensagem de e-mail, o primeiro passo é...','Clicar no botão Escrever (ou Novo E-mail)','Apagar a caixa de entrada','Fechar o navegador',0,1,'2026-08-14 22:12:15.322'),
(96,'basico','O que você digita no campo \"Para\" de um e-mail?','O assunto da mensagem','O endereço de e-mail do destinatário','A sua senha',1,1,'2026-08-14 22:12:15.322'),
(97,'basico','Quais programas permitem fazer chamadas de vídeo pelo computador?','Google Meet, Microsoft Teams e Zoom','Paint e Calculadora','Word e Excel',0,1,'2026-08-14 22:12:15.322'),
(98,'basico','Quando o navegador pedir para usar o microfone e a câmera em uma reunião, você deve...','Fechar a página','Permitir (confirmar) o uso','Desligar o computador',1,1,'2026-08-14 22:12:15.322'),
(99,'basico','O que é o WhatsApp Web?','Um aplicativo de fotos','Uma versão do WhatsApp para usar no computador','Um navegador de internet',1,1,'2026-08-14 22:12:15.322'),
(100,'basico','Como você conecta o WhatsApp do celular ao WhatsApp Web?','Escaneando o código QR exibido na tela do computador','Digitando um código de 6 dígitos','Enviando um e-mail',0,1,'2026-08-14 22:12:15.322'),
(101,'basico','O que é o Google Drive?','Uma \"nuvem\" (pen drive virtual) que guarda seus arquivos na internet','Um programa de desenho','Um jogo de corrida',0,1,'2026-08-14 22:12:15.322'),
(102,'basico','Para que serve o Canva?','Criar cartões, banners e apresentações','Escutar músicas','Traduzir textos',0,1,'2026-08-14 22:12:15.322'),
(103,'basico','O que é o Google Tradutor?','Um aplicativo que traduz palavras e textos para o português','Um navegador','Um antivírus',0,1,'2026-08-14 22:12:15.322'),
(104,'basico','Como você aumenta o tamanho das letras em um site?','Segurando Ctrl e pressionando o sinal de +','Pressionando Caps Lock','Segurando Alt e pressionando F4',0,1,'2026-08-14 22:12:15.322'),
(105,'basico','Qual atalho diminui as letras de um site?','Ctrl + -','Ctrl + =','Shift + +',0,1,'2026-08-14 22:12:15.322'),
(106,'basico','Onde fica a opção \"Luz noturna\" no Windows?','Configurações → Sistema → Tela','Menu Iniciar → Desligar','Painel do navegador',0,1,'2026-08-14 22:12:15.322'),
(107,'basico','Para que serve o modo \"Luz noturna\" do Windows?','Aumentar o brilho da tela','Reduzir o cansaço visual e ajudar na qualidade do sono','Acelerar a internet',1,1,'2026-08-14 22:12:15.322'),
(108,'avancado','Qual é um bom nome para um arquivo?','Documento1','Novo arquivo','Trabalho de Informática 2026',2,1,'2026-08-14 22:12:15.322'),
(109,'avancado','Onde você deve guardar seus arquivos?','Nas pastas padrão do sistema: Documentos, Vídeos, Imagens e Downloads','Espalhados pela Área de Trabalho','Na Lixeira',0,1,'2026-08-14 22:12:15.322'),
(110,'avancado','Quando o Windows exibe o aviso \"Atualizar e reiniciar\", você deve...','Ignorar o aviso','Salvar seus trabalhos e fazer o procedimento','Desligar o computador na tomada',1,1,'2026-08-14 22:12:15.322'),
(111,'avancado','De que você deve desconfiar nos e-mails que recebe?','De links e anexos de desconhecidos ou mensagens com prêmios fáceis','De mensagens da sua família','De boletos do seu banco',0,1,'2026-08-14 22:12:15.322'),
(112,'avancado','O que golpistas costumam imitar para roubar dados?','A barra de tarefas','As configurações do Windows','Páginas de bancos e lojas',2,1,'2026-08-14 22:12:15.322'),
(113,'avancado','De onde você deve baixar programas?','De páginas oficiais e confiáveis','De qualquer link recebido por e-mail','De anúncios de prêmios',0,1,'2026-08-14 22:12:15.322'),
(114,'avancado','O que faz o atalho Ctrl + X?','Copia o item selecionado','Recorta o item, removendo-o do lugar original para mover','Desfaz a última ação',1,1,'2026-08-14 22:12:15.322'),
(115,'avancado','O que faz o atalho Ctrl + A?','Seleciona todo o texto ou todos os arquivos visíveis','Abre uma nova janela','Salva o arquivo',0,1,'2026-08-14 22:12:15.322'),
(116,'avancado','O que faz o atalho Ctrl + F?','Fecha a janela','Abre uma barra de busca rápida para localizar uma palavra','Copia o texto',1,1,'2026-08-14 22:12:15.322'),
(117,'avancado','O que faz o atalho Ctrl + T no navegador?','Fecha a aba ativa','Abre uma nova aba (guia)','Atualiza a página',1,1,'2026-08-14 22:12:15.322'),
(118,'avancado','O que faz o atalho Ctrl + W?','Fecha a aba ativa','Abre uma nova aba','Salva o arquivo',0,1,'2026-08-14 22:12:15.322'),
(119,'avancado','O que faz o atalho Ctrl + Shift + T?','Reabre a última aba fechada','Abre o Gerenciador de Tarefas','Desfaz a última ação',0,1,'2026-08-14 22:12:15.322'),
(120,'avancado','O que faz o atalho Alt + Tab?','Alterna entre as janelas e os programas abertos','Fecha todos os programas','Mostra a Área de Trabalho',0,1,'2026-08-14 22:12:15.322'),
(121,'avancado','O que faz o atalho Windows + D?','Abre o menu Iniciar','Minimiza todas as janelas e mostra a Área de Trabalho','Desliga o computador',1,1,'2026-08-14 22:12:15.322'),
(122,'avancado','Onde você encaixa um pen drive no computador?','Em uma entrada USB','Na entrada de fone de ouvido','No leitor de cartões',0,1,'2026-08-14 22:12:15.322'),
(123,'avancado','Qual é a forma segura de retirar o pen drive?','Puxando-o imediatamente após usar','Clicando no ícone de USB perto do relógio e escolhendo \"Remover Hardware com Segurança\"','Desligando o computador antes',1,1,'2026-08-14 22:12:15.322'),
(124,'avancado','Por que esperar o aviso para retirar o pen drive?','Para não danificar o computador','Para evitar que os arquivos sejam corrompidos','Para carregar o pen drive',1,1,'2026-08-14 22:12:15.322'),
(125,'avancado','Como você fecha um programa travado?','Pressionando Ctrl + Shift + Esc, selecionando o programa no Gerenciador de Tarefas e clicando em \"Finalizar tarefa\"','Desligando o computador na tomada','Pressionando Caps Lock',0,1,'2026-08-14 22:12:15.322'),
(126,'avancado','O que fazer se o computador congelar completamente?','Esperar alguns minutos','Segurar o botão de ligar por 10 segundos para forçar o desligamento','Puxar o cabo do monitor',1,1,'2026-08-14 22:12:15.322'),
(127,'avancado','Se a internet cair em toda a casa, o que você deve fazer?','Retirar o modem da tomada, esperar 30 segundos e ligá-lo novamente','Comprar um computador novo','Apagar os arquivos da internet',0,1,'2026-08-14 22:12:15.322'),
(128,'avancado','Se o som não está funcionando, o que você deve verificar primeiro?','Se o volume está no mudo no ícone de alto-falante','Se a internet está conectada','Se o pen drive está encaixado',0,1,'2026-08-14 22:12:15.322'),
(129,'avancado','Como você faz os ícones que sumiram voltar à Área de Trabalho?','Desligando e ligando o computador','Instalando um programa novo','Clicando com o botão direito em um espaço vazio, indo em Exibir e marcando \"Mostrar ícones da área de trabalho\"',2,1,'2026-08-14 22:12:15.322'),
(130,'programador','Qual tag HTML é usada para criar um título de nível 1?','<h1>','<p>','<title>',0,1,'2026-08-14 22:12:15.322'),
(131,'programador','Qual atributo define o endereço de uma imagem na tag <img>?','href','src','link',1,1,'2026-08-14 22:12:15.322'),
(132,'programador','Qual tag cria um link em HTML?','<link>','<url>','<a>',2,1,'2026-08-14 22:12:15.322'),
(133,'programador','Qual tag é usada para criar uma lista com marcadores (pontos)?','<ol>','<ul>','<list>',1,1,'2026-08-14 22:12:15.322'),
(134,'programador','Onde o conteúdo visível da página deve ficar?','Dentro de <head>','Dentro de <body>','Dentro de <html> apenas',1,1,'2026-08-14 22:12:15.322'),
(135,'programador','Qual tag insere uma quebra de linha?','<br>','<lb>','<nl>',0,1,'2026-08-14 22:12:15.322'),
(136,'programador','Qual tag representa um parágrafo de texto?','<text>','<p>','<par>',1,1,'2026-08-14 22:12:15.322'),
(137,'programador','Qual atributo abre o link em uma nova aba?','target=\"_blank\"','new=\"true\"','open=\"new\"',0,1,'2026-08-14 22:12:15.322'),
(138,'programador','O que significa a sigla HTML?','HyperText Markup Language','HighText Machine Language','Hyperlink and Text Markup Language',0,1,'2026-08-14 22:12:15.322'),
(139,'programador','Qual tag é usada para incorporar uma imagem?','<picture>','<image>','<img>',2,1,'2026-08-14 22:12:15.322'),
(140,'programador','Qual propriedade CSS define a cor do texto?','color','text-color','font-color',0,1,'2026-08-14 22:12:15.322'),
(141,'programador','Qual propriedade altera o tamanho da fonte?','text-size','font-size','size',1,1,'2026-08-14 22:12:15.322'),
(142,'programador','Qual seleciona elementos pelo atributo id no CSS?','.nome','#nome','*nome',1,1,'2026-08-14 22:12:15.322'),
(143,'programador','Qual propriedade cria uma margem interna?','margin','border','padding',2,1,'2026-08-14 22:12:15.322'),
(144,'programador','Qual propriedade define o espaçamento externo?','margin','padding','gap',0,1,'2026-08-14 22:12:15.322'),
(145,'programador','O que significa a sigla CSS?','Cascading Style Sheets','Computer Style System','Creative Style Source',0,1,'2026-08-14 22:12:15.322'),
(146,'programador','Qual propriedade arredonda os cantos de um elemento?','radius','border-radius','corner-radius',1,1,'2026-08-14 22:12:15.322'),
(147,'programador','Qual propriedade esconde um elemento da página?','display: none','visibility: false','hidden: true',0,1,'2026-08-14 22:12:15.322'),
(148,'programador','Qual valor de position fixa o elemento em relação à tela?','relative','absolute','fixed',2,1,'2026-08-14 22:12:15.322'),
(149,'programador','Qual propriedade deixa o texto em negrito?','font-weight','text-bold','font-bold',0,1,'2026-08-14 22:12:15.322'),
(150,'programador','Qual palavra-chave declara uma variável com escopo de bloco?','var','let','dim',1,1,'2026-08-14 22:12:15.322'),
(151,'programador','Qual função exibe uma mensagem no console?','console.log()','print()','debug.log()',0,1,'2026-08-14 22:12:15.322'),
(152,'programador','Qual operador verifica igualdade de valor E tipo?','==','=','===',2,1,'2026-08-14 22:12:15.322'),
(153,'programador','Qual estrutura repete um bloco enquanto a condição for verdadeira?','if','while','switch',1,1,'2026-08-14 22:12:15.322'),
(154,'programador','O que a função prompt() faz?','Exibe uma caixa de entrada de texto','Fecha a aba do navegador','Envia dados para o servidor',0,1,'2026-08-14 22:12:15.322'),
(155,'programador','Como se chama uma função sem nome?','Função anônima','Função vazia','Função invisível',0,1,'2026-08-14 22:12:15.322'),
(156,'programador','Qual método adiciona um item ao final de um array?','push()','add()','append()',0,1,'2026-08-14 22:12:15.322'),
(157,'programador','O que é DOM?','Um banco de dados','A estrutura de objetos que representa a página','Uma linguagem de estilo',1,1,'2026-08-14 22:12:15.322'),
(158,'programador','Qual palavra-chave declara uma constante?','const','fix','static',0,1,'2026-08-14 22:12:15.322'),
(159,'programador','Qual método converte um texto em número inteiro?','parseInt()','toNumber()','NumberString()',0,1,'2026-08-14 22:12:15.322'),
(160,'programador','O que é um banco de dados relacional?','Dados organizados em tabelas relacionadas','Uma pasta de arquivos soltos','Uma planilha única e simples',0,1,'2026-08-14 22:12:15.322'),
(161,'programador','O que significa a sigla SQL?','Structured Query Language','Simple Question Language','System Quick Lookup',0,1,'2026-08-14 22:12:15.322'),
(162,'programador','Qual comando SQL busca dados de uma tabela?','INSERT','SELECT','UPDATE',1,1,'2026-08-14 22:12:15.322'),
(163,'programador','Qual comando SQL insere dados em uma tabela?','INSERT INTO','ADD ROW','CREATE VALUE',0,1,'2026-08-14 22:12:15.322'),
(164,'programador','O que é uma chave primária (primary key)?','Um identificador único de cada registro','Uma senha de acesso','O primeiro campo da tabela',0,1,'2026-08-14 22:12:15.322'),
(165,'programador','Qual comando remove um registro de uma tabela?','DROP ROW','DELETE FROM','REMOVE',1,1,'2026-08-14 22:12:15.322'),
(166,'programador','O que é uma Foreign Key (chave estrangeira)?','Uma referência a uma chave de outra tabela','Uma coluna de texto estrangeiro','Um índice de busca externa',0,1,'2026-08-14 22:12:15.322'),
(167,'programador','Qual cláusula SQL filtra os resultados?','SORT','FILTER','WHERE',2,1,'2026-08-14 22:12:15.322'),
(168,'programador','Qual comando cria uma nova tabela?','CREATE TABLE','NEW TABLE','MAKE TABLE',0,1,'2026-08-14 22:12:15.322'),
(169,'programador','Qual ORM é utilizado no backend do SEADI?','Sequelize','Prisma','Mongoose',1,1,'2026-08-14 22:12:15.322'),
(170,'programador','O que é um algoritmo?','Uma sequência de passos para resolver um problema','Um tipo de memória','Um modelo de computador',0,1,'2026-08-14 22:12:15.322'),
(171,'programador','Qual é a função de um compilador?','Traduzir o código-fonte para linguagem de máquina','Armazenar dados do usuário','Conectar-se à internet',0,1,'2026-08-14 22:12:15.322'),
(172,'programador','O que é uma variável na programação?','Um espaço para armazenar um valor','Um tipo de tela','Um comando de repetição',0,1,'2026-08-14 22:12:15.322'),
(173,'programador','Qual estrutura decide entre dois caminhos no código?','for','if/else','while',1,1,'2026-08-14 22:12:15.322'),
(174,'programador','O que é um loop?','Uma estrutura que repete um trecho de código','Uma variável global','Um erro de sintaxe',0,1,'2026-08-14 22:12:15.322'),
(175,'programador','O que é uma função?','Um bloco de código reutilizável','Uma tecla do teclado','Um tipo de dado',0,1,'2026-08-14 22:12:15.322'),
(176,'programador','O que significa \"bug\" na programação?','Um erro no código','Um computador rápido','Uma função especial',0,1,'2026-08-14 22:12:15.322'),
(177,'programador','Qual linguagem é usada para programar o backend do SEADI?','Python','TypeScript','Java',1,1,'2026-08-14 22:12:15.322'),
(178,'programador','O que é um array?','Uma lista de valores','Um tipo de monitor','Um comando de impressão',0,1,'2026-08-14 22:12:15.322'),
(179,'programador','Qual operador aritmético calcula o resto de uma divisão?','/','%','**',1,1,'2026-08-14 22:12:15.322');
/*!40000 ALTER TABLE `Questao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RedefinicaoSenha`
--

DROP TABLE IF EXISTS `RedefinicaoSenha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `RedefinicaoSenha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `codigo` varchar(191) NOT NULL,
  `tentativas` int(11) NOT NULL DEFAULT 0,
  `expiraEm` datetime(3) NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `criadoEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RedefinicaoSenha`
--

LOCK TABLES `RedefinicaoSenha` WRITE;
/*!40000 ALTER TABLE `RedefinicaoSenha` DISABLE KEYS */;
/*!40000 ALTER TABLE `RedefinicaoSenha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TentativaLogin`
--

DROP TABLE IF EXISTS `TentativaLogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TentativaLogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioId` int(11) DEFAULT NULL,
  `ip` varchar(191) DEFAULT NULL,
  `momento` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `sucesso` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TentativaLogin_usuarioId_momento_idx` (`usuarioId`,`momento`),
  KEY `TentativaLogin_ip_momento_idx` (`ip`,`momento`),
  CONSTRAINT `TentativaLogin_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `Usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TentativaLogin`
--

LOCK TABLES `TentativaLogin` WRITE;
/*!40000 ALTER TABLE `TentativaLogin` DISABLE KEYS */;
INSERT INTO `TentativaLogin` VALUES
(1,NULL,'2804:29b8:5156:68f4:7111:8772:8b48:e61f','2026-08-14 22:26:44.474',0),
(2,NULL,'2804:29b8:5156:68f4:7111:8772:8b48:e61f','2026-08-14 22:26:55.533',0),
(3,NULL,'177.37.132.97','2026-08-14 22:28:02.401',0),
(4,NULL,'177.37.132.97','2026-08-14 22:29:46.152',0),
(5,NULL,'2804:29b8:5156:68f4:7d7a:41ff:409d:43ce','2026-08-14 22:30:10.244',0),
(6,1,'2804:29b8:5156:68f4:7d7a:41ff:409d:43ce','2026-08-14 22:30:48.426',0),
(7,1,'2804:29b8:5156:68f4:7d7a:41ff:409d:43ce','2026-08-14 22:30:51.843',1),
(8,NULL,'2804:29b8:5156:68f4:5756:861c:de1c:9c18','2026-08-16 15:16:56.822',0),
(9,NULL,'2804:29b8:5156:68f4:5756:861c:de1c:9c18','2026-08-16 15:17:02.933',0),
(10,1,'2804:29b8:5156:68f4:5756:861c:de1c:9c18','2026-08-16 15:17:11.744',1);
/*!40000 ALTER TABLE `TentativaLogin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario`
--

DROP TABLE IF EXISTS `Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `senha` varchar(191) NOT NULL,
  `telefone` varchar(191) DEFAULT NULL,
  `dataNascimento` datetime(3) DEFAULT NULL,
  `fotoUrl` varchar(191) DEFAULT NULL,
  `ultimoAcesso` datetime(3) DEFAULT NULL,
  `criadoEm` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `atualizadoEm` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Usuario_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario`
--

LOCK TABLES `Usuario` WRITE;
/*!40000 ALTER TABLE `Usuario` DISABLE KEYS */;
INSERT INTO `Usuario` VALUES
(1,'Divaldo Fernandes','divaldofedantas@gmail.com','$2b$10$5enUdWRlBnapW2I8DdlJmOGbOal984ln98Sk2E17jgTt6cA1Gmzci',NULL,NULL,NULL,'2026-08-16 15:20:09.999','2026-08-14 22:28:02.245','2026-08-16 15:20:10.000'),
(2,'Felipe','827373636hhh@gmail.com','$2b$10$iNd3oEQt2odwF4sfBu0ToOhOvA4jfVtCe8mwQ3iGrsnzdtZKhzz5C',NULL,NULL,'/uploads/avatars/1786828980910-87402.jpg','2026-08-15 21:34:20.120','2026-08-15 21:19:30.927','2026-08-15 21:34:20.121'),
(3,'Gabriel','gabrielsantinhos@gmail.com','$2b$10$WtnOThx3Km.ibFmttT4WL.yT5sM9DNvVgGlW5to/0r68tOvIRZpMq',NULL,NULL,NULL,'2026-08-16 18:12:19.781','2026-08-16 14:58:59.890','2026-08-16 18:12:19.782');
/*!40000 ALTER TABLE `Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES
('d84ff73f-0f24-4611-a668-649326b7d229','e69c9f21be2b53770b13ea52bf6c4f304a9fc86b41f1e932729ec2de45574341','2026-08-16 18:21:47.582','20260816190000_baseline','',NULL,'2026-08-16 18:21:47.582',0);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'seadi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-16 18:23:43
